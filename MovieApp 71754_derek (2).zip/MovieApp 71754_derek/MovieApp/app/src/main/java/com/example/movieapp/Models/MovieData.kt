package com.example.movieapp.Models

data class MovieData (
    val title: String,
    val overview: String,
    val runtime: String,
    val posterurl: String // URL to the movie poster
)